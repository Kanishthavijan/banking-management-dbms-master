# Banking_management_dmbs
This is a banking management system in which tkinter is used for front and and sqlite3 is used for backend.
You can run this by executing main.py.
You may login as a banker and your credentials are:-
login id :- "10"
password :- "10CEO"
Then you can create another banker or customer and run this program according to your needs.
